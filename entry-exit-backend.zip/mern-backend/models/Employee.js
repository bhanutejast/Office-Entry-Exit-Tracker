const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
    fullName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['Employee', 'Manager', 'Admin'], default: 'Employee' },
    department: { type: String, required: true },
    joiningDate: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Employee', EmployeeSchema);