const mongoose = require('mongoose');

const AttendanceSchema = new mongoose.Schema({
    employeeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee', required: true },
    clockIn: { type: Date, default: Date.now },
    clockOut: { type: Date },
    location: {
        latitude: { type: Number, required: true },
        longitude: { type: Number, required: true }
    },
    status: { type: String, enum: ['On Time', 'Late', 'Half Day'], default: 'On Time' }
});

module.exports = mongoose.model('Attendance', AttendanceSchema);