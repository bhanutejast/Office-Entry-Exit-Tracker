const mongoose = require('mongoose');

const PayrollSchema = new mongoose.Schema({
    employeeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee', required: true },
    monthlyBaseSalary: { type: Number, required: true },
    houseRentAllowance: { type: Number, default: 0 },
    providentFundDeduction: { type: Number, default: 0 },
    paymentStatus: { type: String, enum: ['Paid', 'Pending', 'Processing'], default: 'Pending' },
    processedDate: { type: Date }
});

module.exports = mongoose.model('Payroll', PayrollSchema);