const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const employeeRoutes = require('./routes/employeeRoutes'); 
const attendanceRoutes = require('./routes/attendanceRoutes'); 
const payrollRoutes = require('./routes/payrollRoutes'); // 1. Imported Payroll Routes

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Your MongoDB Atlas Connection String
const MONGO_URI = "mongodb+srv://morubhanutej_db_user:Bhanu123@cluster0.ai4qts1.mongodb.net/?appName=Cluster0";

mongoose.connect(MONGO_URI)
  .then(() => console.log("✅ Successfully connected to MongoDB Atlas!"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// Route Middlewares
app.use('/api/employees', employeeRoutes);     // Handles onboarding & directory
app.use('/api/attendance', attendanceRoutes);   // Handles clock-ins & tracking
app.use('/api/payroll', payrollRoutes);        // 2. Handles salary slips & calculations

// Serve static files from React build
app.use(express.static(path.join(__dirname, '../keka-frontend/dist')));

// Fallback to serve index.html for React SPA
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '../keka-frontend/dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Server is listening on port ${PORT}`);
});