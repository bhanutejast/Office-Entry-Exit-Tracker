const express = require('express');
const router = express.Router();
const Payroll = require('../models/Payroll');

// Generate/Assign Payroll to an Employee
router.post('/generate', async (req, res) => {
    try {
        const salarySlip = new Payroll(req.body);
        const savedSlip = await salarySlip.save();
        res.status(201).json({ success: true, data: savedSlip });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// Get Payroll details for a specific Employee
router.get('/:employeeId', async (req, res) => {
    try {
        const payrollInfo = await Payroll.findOne({ employeeId: req.params.employeeId });
        if (!payrollInfo) return res.status(404).json({ success: false, message: "Payroll record not found" });
        res.status(200).json({ success: true, data: payrollInfo });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;