const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');
const Employee = require('../models/Employee');

// Secure Unified Punch (Entry / Exit) Endpoint
router.post('/punch', async (req, res) => {
    const { employeeId, password, action, location } = req.body;

    try {
        // 1. Verify employee exists
        const employee = await Employee.findById(employeeId);
        if (!employee) {
            return res.status(404).json({ success: false, error: 'Employee not found.' });
        }

        // 2. Print verification log to console (PIN check)
        console.log("Input:", password, "Target:", employee.password);

        // 3. Validate Password / PIN
        if (employee.password !== password) {
            return res.status(401).json({ success: false, error: 'Incorrect Secret Password or PIN.' });
        }

        // 4. Get latest attendance log to check state machine
        const latestRecord = await Attendance.findOne({ employeeId }).sort({ clockIn: -1 });
        const isCurrentlyIn = latestRecord && !latestRecord.clockOut;

        if (action === 'Entry') {
            if (isCurrentlyIn) {
                return res.status(400).json({ success: false, error: 'Action Denied: Employee is already checked in.' });
            }

            // Create entry record
            const newRecord = new Attendance({
                employeeId,
                location: {
                    latitude: location?.latitude || 12.9716,
                    longitude: location?.longitude || 77.5946
                },
                status: 'On Time' // Default status
            });
            const savedRecord = await newRecord.save();
            return res.status(201).json({ success: true, action: 'Entry', data: savedRecord });

        } else if (action === 'Exit') {
            if (!isCurrentlyIn) {
                return res.status(400).json({ success: false, error: 'Action Denied: Employee is already checked out.' });
            }

            // Update exit record
            latestRecord.clockOut = Date.now();
            const savedRecord = await latestRecord.save();
            return res.status(200).json({ success: true, action: 'Exit', data: savedRecord });
        } else {
            return res.status(400).json({ success: false, error: 'Invalid action specified.' });
        }

    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Retrieve all attendance logs populated with employee profile info
router.get('/logs', async (req, res) => {
    try {
        const logs = await Attendance.find().populate('employeeId').sort({ clockIn: -1 });
        res.status(200).json({ success: true, data: logs });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;