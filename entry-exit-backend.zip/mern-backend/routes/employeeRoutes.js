const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');
const Attendance = require('../models/Attendance');
const Payroll = require('../models/Payroll');

// HRM Pulse Onboarding Endpoint
router.post('/add', async (req, res) => {
    try {
        const newEmployee = new Employee(req.body);
        const savedEmployee = await newEmployee.save();
        res.status(201).json({ success: true, data: savedEmployee });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// HRM Pulse Employee Directory Endpoint (with dynamic checked-in status)
router.get('/all', async (req, res) => {
    try {
        const employees = await Employee.find();
        
        const data = await Promise.all(employees.map(async (emp) => {
            const latestAttendance = await Attendance.findOne({ employeeId: emp._id }).sort({ clockIn: -1 });
            const currentStatus = (latestAttendance && !latestAttendance.clockOut) ? 'In' : 'Out';
            return {
                ...emp.toObject(),
                currentStatus
            };
        }));
        
        res.status(200).json({ success: true, data });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// HRM Pulse Offboarding (Delete Employee) Endpoint
router.delete('/:id', async (req, res) => {
    try {
        const deletedEmployee = await Employee.findByIdAndDelete(req.params.id);
        if (!deletedEmployee) {
            return res.status(404).json({ success: false, error: "Employee not found." });
        }
        
        // Clean up related attendance and payroll records
        await Attendance.deleteMany({ employeeId: req.params.id });
        await Payroll.deleteMany({ employeeId: req.params.id });
        
        res.status(200).json({ success: true, message: "Employee offboarded successfully." });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Admin Edit PIN Endpoint (direct overwrite)
router.put('/:id/pin', async (req, res) => {
    const { password } = req.body;
    try {
        const employee = await Employee.findById(req.params.id);
        if (!employee) {
            return res.status(404).json({ success: false, error: "Employee not found." });
        }
        
        console.log("Admin Overwrite PIN for:", employee.fullName, "New PIN:", password);
        employee.password = password;
        await employee.save();
        res.status(200).json({ success: true, message: "Employee PIN updated successfully by Admin." });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Change PIN Endpoint
router.post('/change-pin', async (req, res) => {
    const { employeeId, currentPin, newPin } = req.body;
    try {
        const employee = await Employee.findById(employeeId);
        if (!employee) {
            return res.status(404).json({ success: false, error: "Employee not found." });
        }

        // Print verification logs to the console
        console.log("Input:", currentPin, "Target:", employee.password);

        if (employee.password !== currentPin) {
            return res.status(401).json({ success: false, error: "Incorrect Current PIN." });
        }

        employee.password = newPin;
        await employee.save();

        res.status(200).json({ success: true, message: "PIN changed successfully." });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Seed Employee Database Endpoint (Initial Team Roster with universal "1234" PIN)
router.post('/seed', async (req, res) => {
    try {
        // Clear all database tables
        await Employee.deleteMany({});
        await Attendance.deleteMany({});
        await Payroll.deleteMany({});

        const seedEmployees = [
            { fullName: 'Siddharth Choudhary', email: 'siddharth.choudhary@hrmpulse.com', role: 'Manager', department: 'Technical', password: '1234' },
            { fullName: 'Sri Vibhu', email: 'sri.vibhu@hrmpulse.com', role: 'Employee', department: 'Technical', password: '1234' },
            { fullName: 'Bhanu Moru', email: 'bhanu.moru@hrmpulse.com', role: 'Admin', department: 'HR', password: '1234' },
            { fullName: 'Ananya Rao', email: 'ananya.rao@hrmpulse.com', role: 'Manager', department: 'Marketing', password: '1234' }
        ];

        const savedEmployees = await Employee.insertMany(seedEmployees);
        res.status(201).json({ success: true, data: savedEmployees });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;